Sambafied AEM Desktop for Windows x64
Beta tester build 0.1.0.119

Install or update

1. Extract this ZIP. Save your work, let transfers finish and quit Sambafied from the tray.
2. If this PC already trusts the Sambafied tester certificate, go to step 3. Otherwise open Sambafied-Tester.cer and compare the Details > Thumbprint value with 2528F113E07D0DD1B114668C0AE70691F7E87233. For that matching certificate, select Install Certificate > Local Machine > Place all certificates in the following store > Trusted People.
3. Open the .msix, confirm version 0.1.0.119, and select Install or Update. Open Sambafied AEM from Start. Keep existing work folders and app data. This ZIP is a manual tester update.

Connect to the LAN Author

1. For a personal licence, sign in to Sambafied, then enter your licence key. Successful activation closes the dialog and shows a green confirmation.
2. Choose Add your first connection. Select Author, On-premises, and Development. Enter http://192.168.1.80:4502 and enable Allow HTTP for a local or private LAN development Author. HTTP is unencrypted. Choose your configured AEM sign-in method.
3. Enter a connection name. Check the suggested workfolder or use Browse to choose one, then select Add Instance. Browse works locally. Saving still requires the configuration service. If saving reports that the service is unavailable, use the form’s recovery action and keep the draft.
4. Verify you can sign in to AEM and open the expected DAM folder. If setup fails, report the build version, the step, and the full error message. Keep licence keys and passwords private.

Verification

Source commit bf363549ab052e4b53d4bb0ac332bb21c3f7eed3
MSIX SHA-256 003dacfedb3ae8fa098cc30d5d69471ada1b2265d62de6b0bfce6d2657cce87c
Windows verified the test signature and the package build checked 42 payload files. The tester’s LAN Author and installation remain to be verified. Local-only write qualification remains limited to loopback.
